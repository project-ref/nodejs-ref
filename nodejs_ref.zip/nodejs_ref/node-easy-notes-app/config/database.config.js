var uname = 'admin';
var pwd = '123456';
var host = 'localhost:27017';
var dbname = 'easy-notes';

module.exports = {
    url: 'mongodb://'+uname+':'+pwd+'@'+host+'/'+dbname
}