﻿<?php include "header.php";?>

<nav class="navbar-default navbar-side" role="navigation">
	<div class="sidebar-collapse">
		<ul class="nav" id="main-menu">

			<li>
				<a href="index.php"><i class="fa fa-cog"></i> Set Connection</a>
			</li>
			<li>
				<a href="notes.php" class="active-menu"><i class="fa fa-list"></i> Notes</a>
			</li> 
			
		</ul>

	</div>

</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
	<div class="header"> 
		<h1 class="page-header">
			Notes
		</h1>
		<ol class="breadcrumb">
		<li><a href="<?php echo connection.php;?>">Connection</a></li>
		<li class="active">Notes</li>
		</ol> 							
	</div>
	<div id="page-inner"> 
               
		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-heading">
						 Notes
					</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover" id="notes-table">
								<thead>
									<tr>
										<th>Id</th>
										<th>Title</th>
										<th>Content</th>
										<th>Date</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									
								</tbody>
							</table>
						</div>
						
					</div>
				</div>
				<!--End Advanced Tables -->
			</div>
		</div>
			
<?php include "footer.php";?>			