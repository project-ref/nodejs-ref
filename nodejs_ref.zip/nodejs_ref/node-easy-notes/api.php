<?php
	include "api_config.php";
	
	$action = (isset($_POST['action']))?$_POST['action']:"";
	
	switch ($action) {
	
		case "SetConnection":
		
			$URL 				= "http://localhost:3000/conn/";
			$data['username'] 	= $_POST['username'];
			$data['pwd'] 		= $_POST['password'];
			$data['hostname'] 	= $_POST['host'];
			$data['dbname'] 	= $_POST['dbname'];
			$result 			= RestCurl::post($URL, $data);
			echo "<pre>";
			print_r($result['status']);	
			break;
		
		case "getNotes":
			$URL = "http://localhost:3000/notes/";
			$result = RestCurl::get($URL);
			echo "<pre>";
			print_r($result['status']);	
			break;
		
		case "getNote":
			$id = "5cbff9e37c15ce34b84cec0b";
			$URL = "http://localhost:3000/notes/".$id;
			$result = RestCurl::get($URL);
			echo "<pre>";
			print_r($result['status']);	
			break;
		
		case "createNote":
			$URL = "http://localhost:3000/notes/";
			$data['title'] = "Test title2";
			$data['content'] = "Test content2";
			$result = RestCurl::post($URL, $data);
			echo "<pre>";
			print_r($result['status']);	
			break;
		
		case "updateNote":	
			$id = "5cbff9e37c15ce34b84cec0b";
			$URL = "http://localhost:3000/notes/".$id;
			$data['title'] = "Test title2";
			$data['content'] = "Test content2";
			$result = RestCurl::put($URL, $data);
			echo "<pre>";
			print_r($result['status']);	
			break;
		
		case "deleteNote";
			$id = "5cbff9e37c15ce34b84cec0b";
			$URL = "http://localhost:3000/notes/".$id;
			$result = RestCurl::delete($URL); 
			echo "<pre>";
			print_r($result['status']);	
			break;
		default:
			$result = "No action";
			echo $result;
			
			
	}
	
	
	
?>
