<?php
	include "api_config.php";
	
	// POST - set db connection
	$URL = "http://localhost:3000/conn/";
	$data['username'] = "admin";
	$data['pwd'] = "123456";
	$data['hostname'] = "localhost:27017";
	$data['dbname'] = "easy-notes";
	$result = RestCurl::post($URL, $data);
	
	
	// GET all records
	$URL = "http://localhost:3000/notes/";
	//$result = RestCurl::get($URL);
	
	// GET single record
	$id = "5cbff9e37c15ce34b84cec0b";
	$URL = "http://localhost:3000/notes/".$id;
	//$result = RestCurl::get($URL);
	
	// POST
	$URL = "http://localhost:3000/notes/";
	$data['title'] = "Test title2";
	$data['content'] = "Test content2";
	//$result = RestCurl::post($URL, $data);
	
	// PUT
	$id = "5cbff9e37c15ce34b84cec0b";
	$URL = "http://localhost:3000/notes/".$id;
	$data['title'] = "Test title2";
	$data['content'] = "Test content2";
	//$result = RestCurl::put($URL, $data);
	
	// DELETE
	$id = "5cbff9e37c15ce34b84cec0b";
	$URL = "http://localhost:3000/notes/".$id;
	//$result = RestCurl::delete($URL); 
	

	echo "<pre>";
	print_r($result);
	
?>
