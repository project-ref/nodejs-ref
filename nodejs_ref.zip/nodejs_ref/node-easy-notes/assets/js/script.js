$(function() {

	$("#connection-form").submit(function() {
		 $.ajax({
            type:"POST",
            url:$("#connection-form").attr("action"),
            data:$("#connection-form").serialize(),//only input
            success: function(response){
                console.log(response);
				
            }
        });
		return false;
    });
});